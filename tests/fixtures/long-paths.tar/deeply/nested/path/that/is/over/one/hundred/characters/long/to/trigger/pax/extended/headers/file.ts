nested path content
